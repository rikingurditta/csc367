#!/bin/bash
#SBATCH --nodes=1
#SBATCH --partition=csc367-compute
#SBATCH --job-name lab06
#SBATCH --output=lab06_%j.out


./lab6.out
