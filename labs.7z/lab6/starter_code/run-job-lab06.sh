#!/bin/bash

rm -f *.out
#build the code
make

#run the job on the GPU server
sbatch job-lab06.sh
