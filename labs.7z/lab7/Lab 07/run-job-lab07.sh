#!/bin/bash

#build the code
make

#run the job on the GPU server
sbatch job-lab07.sh
