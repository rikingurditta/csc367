#!/bin/bash
#SBATCH --nodes=1
#SBATCH --partition=csc367-compute
#SBATCH --job-name lab07
#SBATCH --output=lab07_%j.out


./lab7.out
