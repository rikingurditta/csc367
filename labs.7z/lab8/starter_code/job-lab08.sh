#!/bin/bash
#SBATCH --nodes=1
#SBATCH --partition=csc367-compute
#SBATCH --job-name lab08
#SBATCH --output=lab08_%j.out


./lab8.out
