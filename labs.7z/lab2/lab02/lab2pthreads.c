/* ------------
 * This code is provided solely for the personal and private use of 
 * students taking the CSC367 course at the University of Toronto.
 * Copying for purposes other than this use is expressly prohibited. 
 * All forms of distribution of this code, whether as given or with 
 * any changes, are expressly prohibited. 
 * 
 * Authors: Bogdan Simion, Maryam Dehnavi, Felipe de Azevedo Piovezan
 * 
 * All of the files in this directory and all subdirectories are:
 * Copyright (c) 2020 Bogdan Simion and Maryam Dehnavi
 * -------------
*/

#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>
#include <time.h>

#include "lab2helper.h"

float *input;
float *weights;
float *result;
int32_t n;
int32_t threads;

// Convert struct timespec to seconds
static inline double timespec_to_sec(struct timespec t)
{
	return t.tv_sec * 1.0 + t.tv_nsec / 1000000000.0;
}

// Get time elapsed between t0 and t1
static inline struct timespec difftimespec(struct timespec t1, struct timespec t0)
{
    // assert(t1.tv_nsec < 1000000000);
    // assert(t0.tv_nsec < 1000000000);

    return (t1.tv_nsec >= t0.tv_nsec)
               ? (struct timespec){t1.tv_sec - t0.tv_sec, t1.tv_nsec - t0.tv_nsec}
               : (struct timespec){t1.tv_sec - t0.tv_sec - 1, t1.tv_nsec - t0.tv_nsec + 1000000000};
}

//Implement the next 4 functions.

// Sequential implementation of the array "input" with
// the array "weights", writing the result to "results".
void scale_sequential()
{
    for (int i = 0; i < n; i++)
    {
        result[i] = input[i] * weights[i];
    }
}

// Parallel sharded implementation of the array "input" with
// the array "weights", writing the result to "results".
void *scale_parallel_sharded(void *val)
{
    /* Remember that a thread needs an id. 
     * You should treat val as a pointer
     * to an integer representing the id of the thread.
     */
    int num = n / threads;
    if (n % threads != 0) {  // round up division
        num++;
    }

    int start = *((int *)val) * num;
    for (int i = start; i < start + num && i < n; i++) {
        result[i] = input[i] * weights[i];
    }

    return NULL;
}

// Parallel strided implementation of the array "input" with
// the array "weights", writing the result to "results".
void *scale_parallel_strided(void *val)
{
    /* Remember that a thread needs an id. 
     * You should treat val as a pointer
     * to an integer representing the id of the thread.
     */

    int start = *((int *)val);
    for (int i = start; i < n; i += threads) {
        result[i] = input[i] * weights[i];
    }

    return NULL;
}

enum
{
    SHARDED,
    STRIDED
};

void start_parallel(int mode)
{
    /* Create your threads here
     * with the correct function as argument (based on mode).
     * Notice that each thread will need an ID as argument,
     * so that the thread can tell which indices of the array it should
     * work on. For example, to create ONE thread on sharded mode,
     * you would use:
     *   int id = 0;
     *   pthread_t worker;
     *   pthread_create(&worker, NULL, scale_parallel_sharded, &id);
     *
     * You want to create "thread" threads, so you probably need
    * an array of ids and an array of pthread_t.
     * Don't forget to wait for all the threads to finish before
     * returning from this function (hint: look at pthread_join()).
     */
    int ids[threads];
    pthread_t p_threads[threads];

    for (int i = 0; i < threads; i++) {
        ids[i] = i;
        if (mode == STRIDED) {
            pthread_create(&p_threads[i], NULL, scale_parallel_strided, &ids[i]);
        } else {
            pthread_create(&p_threads[i], NULL, scale_parallel_sharded, &ids[i]);
        }
    }

    for (int i = 0; i < threads; i++) {
        void *retval;
        if (pthread_join(p_threads[i], &retval)) {
            exit(-1);
        }
    }
}

int main(int argc, char **argv)
{
    /**************** Don't change this code **********************/
    if (argc != 2)
    {
        printf("Usage: %s num_threads\n", argv[0]);
        exit(1);
    }

    threads = atoi(argv[1]);
    n = (1 << 29); // 512M floats =  4 x 512MB = 2GB.
    input = gen_input_from_memory(n, 0);
    weights = gen_weight_from_memory(n, 0);
    result = malloc(n * sizeof(float));
    // Total = 3 x 2GB = 6GB.

    /**************** Change the code below **********************/
    // You must keep the order in which implementations are called.
    // You must keep the call to reset_array in between invocations.
    {
        //call your sequential function here
        //and time it. Do not include the lines
        //below in the measurement.
        float time = 0;
        struct timespec before, after;
        clock_gettime(CLOCK_MONOTONIC, &before);
        
        scale_sequential();

        clock_gettime(CLOCK_MONOTONIC, &after);
        struct timespec diff = difftimespec(after, before);
        time = timespec_to_sec(diff);

        printf("sequential = %10.8f\n", time);
        dump_output_to_file(result, n, "sequential_output.txt");
        reset_array(result, n);
    }
    {
        //call your sequential function here *FOR A SECOND TIME*
        //and time it. Do not include the lines
        //below in the measurement.
        //This may seem weird, but observe what happens.
        float time = 0;
        struct timespec before, after;
        clock_gettime(CLOCK_MONOTONIC, &before);
        
        scale_sequential();

        clock_gettime(CLOCK_MONOTONIC, &after);
        struct timespec diff = difftimespec(after, before);
        time = timespec_to_sec(diff);

        printf("sequential = %10.8f\n", time);
        dump_output_to_file(result, n, "sequential_output.txt");
        reset_array(result, n);
    }
    {
        //call your start_parallel function here on strided mode
        //and time it. Do not include the lines
        //below in the measurement.
        float time = 0;
        struct timespec before, after;
        clock_gettime(CLOCK_MONOTONIC, &before);
        
        start_parallel(STRIDED);

        clock_gettime(CLOCK_MONOTONIC, &after);
        struct timespec diff = difftimespec(after, before);
        time = timespec_to_sec(diff);

        printf("parallel strided = %10.8f\n", time);
        dump_output_to_file(result, n, "strided_output.txt");
        reset_array(result, n);
    }
    {
        //call your start_parallel function here on sharded mode
        //and time it. Do not include the lines
        //below in the measurement.
        float time = 0;
        struct timespec before, after;
        clock_gettime(CLOCK_MONOTONIC, &before);
        
        start_parallel(SHARDED);

        clock_gettime(CLOCK_MONOTONIC, &after);
        struct timespec diff = difftimespec(after, before);
        time = timespec_to_sec(diff);
        printf("parallel sharded = %10.8f\n", time);
        dump_output_to_file(result, n, "sharded_output.txt");
        reset_array(result, n);
    }
}
