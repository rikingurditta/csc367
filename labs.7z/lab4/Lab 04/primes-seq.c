// ------------
// This code is provided solely for the personal and private use of
// students taking the CSC367 course at the University of Toronto.
// Copying for purposes other than this use is expressly prohibited.
// All forms of distribution of this code, whether as given or with
// any changes, are expressly prohibited.
//
// Authors: Bogdan Simion, Maryam Dehnavi, Alexey Khrabrov
//
// All of the files in this directory and all subdirectories are:
// Copyright (c) 2020 Bogdan Simion and Maryam Dehnavi
// -------------

#include <assert.h>
#include <omp.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>


static bool is_prime(int n)
{
	assert(n > 0);
	for (int i = 2; i <= n / 2; i++) {
		if (n % i == 0) return false;
	}
	return true;
}

static int primes_count(int n)
{
	int p = 0;
	for (int i = 2; i < n; i++) {
		if (is_prime(i)) p++;
	}
	return p;
}


int main(int argc, char *argv[])
{
	if ((argc < 2) || (atoi(argv[1]) <= 0)) {
		fprintf(stderr, "Invalid arguments\n");
		return 1;
	}
	int N = atoi(argv[1]);

	double time_msec = 0.0;
    double start, end;
    start = omp_get_wtime();
	int p = primes_count(N);
    end = omp_get_wtime();

    time_msec = (end - start) * 1000;

	printf("%d\n", p);
	printf("%f\n", time_msec);
	return 0;
}
